A bluetooth based package for interacting with switchmates
